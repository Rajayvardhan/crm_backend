const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const AttendanceSchema = new Schema({
  employeeID: { type: Schema.Types.ObjectId, ref: 'User', required: true },

  year: { type: Number, required: true },
  month: { type: Number, required: true },
  date: { type: Number, required: true },
  day: { type: String, required: true },

  // 🔹 IN/OUT Timings
  inTime: { type: Date, default: null },
  outTime: { type: Date, default: null },

  // 🔹 Approvals
  inApproved: { type: String, enum: ['Pending', 'Present','Absent' ,null], default: "Absent" },       // Approved by Reception
  outApproved: { type: Boolean, default: false },      // Approved by HR if early OUT
  regularized: { type: Boolean, default: false },      // Any IN/OUT regularize request
  regularizeType: { type: String, enum: ['IN', 'OUT', null], default: null },
  regularizeReason: { type: String, default: null },
  hrRemarks: { type: String, default: null },

  // 🔹 Status flags
  present: { type: String, enum: ['Approvel', 'Present','half-day','Absent' ,null], default: "Absent"  },
  halfDay: { type: Boolean, default: false },
  holiday: { type: Boolean, default: false },          // Auto true if it's a holiday

  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Attendance', AttendanceSchema);
